StreamNest V6

This version keeps the existing StreamNest layout and no-API-key search.

Playback changes:
- Uses YouTube's standard https://www.youtube.com/embed/ player host instead of youtube-nocookie.com.
- Explicitly sets the page referrer policy to strict-origin-when-cross-origin.
- Explicitly sets the iframe referrerPolicy to strict-origin-when-cross-origin.
- Adds playsinline and rel player parameters.

Important:
These changes address a possible embed/referrer configuration issue. They cannot override YouTube, Google Workspace, video-owner, account, or network restrictions. If playback still shows an administrator/network restriction, the restriction is outside StreamNest's code.

To deploy:
1. Download and extract StreamNest_v6.zip.
2. Open your existing Netlify project.
3. Go to Deploys.
4. Upload the extracted streamnest_v6 folder (the folder containing index.html).
5. Wait until the deployment says Published, then refresh your site.

Search still uses community-run Invidious servers and may occasionally be unavailable.
